# Ikig.AI
We all have abilities
